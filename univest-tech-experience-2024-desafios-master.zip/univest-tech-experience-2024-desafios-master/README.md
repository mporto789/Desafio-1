# Univest Tech Experience 2024 - Desafios

> ## Desafio 1 - Supermercado Garibaldi

> ## Desafio 2 - Faculdade EduTech

